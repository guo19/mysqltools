mysqld_pid=`cat $1`
kill -9 $mysqld_pid
