SET NAMES utf8;
CREATE TABLE `messages` (
  `a` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=greek;
INSERT INTO `messages` VALUES ('πτήσης');
